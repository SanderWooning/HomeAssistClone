"""The aftership component."""
